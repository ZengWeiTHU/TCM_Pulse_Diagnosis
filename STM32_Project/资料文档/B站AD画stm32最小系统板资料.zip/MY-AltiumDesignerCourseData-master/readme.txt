该文件为AltiumDesigner教程的附带资料

教程视频地址：https://www.bilibili.com/video/av49043499

作者博客
https://me.csdn.net/ima_xu

文件中base库里面是均已通过验证的3D元件，但不排除使用原因或者其它因素造成的封装库与实际有所偏差，所以请允许我进行免责声明

此开源资源遵循CC BY-SA 3.0